<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Throwable;

class VerifyEmailActivation extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $user;

    public $verificationUrl;

    /**
     * Create a new message instance.
     */
    public function __construct(User $user, string $verificationUrl)
    {
        $this->user = $user;
        $this->verificationUrl = $verificationUrl;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Verifikasi Email - Aktivasi Akun SIAK',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'emails.verify-email-activation',
            with: [
                'user' => $this->user,
                'verificationUrl' => $this->verificationUrl,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, Attachment>
     */
    public function attachments(): array
    {
        return [];
    }

    /**
     * Dipanggil otomatis oleh queue worker (Illuminate\Mail\SendQueuedMailable) setelah semua
     * percobaan kirim habis dan tetap gagal (mis. SMTP transport error) — lihat catatan channel
     * 'mail' di app/Providers/AppServiceProvider.php.
     */
    public function failed(Throwable $exception): void
    {
        Log::channel('mail')->error('Gagal mengirim email verifikasi aktivasi', [
            'to' => $this->user->email,
            'user_id' => $this->user->id,
            'exception' => $exception->getMessage(),
        ]);
    }
}
